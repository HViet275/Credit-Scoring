from __future__ import annotations

from typing import Any

import pandas as pd


def detect_stage(record: dict[str, Any]) -> str:
    tenure = float(record.get("tenure_months") or 0)
    max_dpd = float(record.get("max_dpd") or 0)
    if max_dpd > 0:
        return "C"
    if tenure <= 0:
        return "A"
    return "B"


def detect_stage_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["stage"] = out.apply(lambda r: detect_stage(r.to_dict()), axis=1)
    return out
