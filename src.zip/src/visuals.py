from __future__ import annotations

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from .explain import reason_frequency_table
from .utils import humanize_token


COLOR_MAP = {
    "Decline / Intensive Review": "#ef4444",
    "Decline": "#ef4444",
    "Manual Review": "#f59e0b",
    "Review Or Decline": "#f59e0b",
    "Approve Standard": "#10b981",
    "Approve Preferred": "#059669",
    "Starter Loan Small": "#3b82f6",
    "Starter Loan Standard": "#10b981",
    "Monitor / Standard Queue": "#3b82f6",
    "Intensive Collection Priority": "#ef4444",
    "High Risk Review Priority": "#f59e0b",
}



def plot_single_threshold_bar(score: float, stage: str, policy_thresholds: pd.DataFrame):
    stage_df = policy_thresholds[policy_thresholds["stage"] == stage].copy()
    if stage_df.empty:
        fig = go.Figure()
        fig.update_layout(height=140, margin=dict(l=10, r=10, t=10, b=10))
        return fig

    fig = go.Figure()
    for _, row in stage_df.iterrows():
        fig.add_trace(
            go.Bar(
                x=[row["max_score"] - row["min_score"]],
                y=["Score Band"],
                base=[row["min_score"]],
                orientation="h",
                name=row["decision"],
                marker_color=COLOR_MAP.get(row["decision"], "#94a3b8"),
                hovertemplate=f"{row['decision']}<br>{row['score_range']}<extra></extra>",
            )
        )
    fig.add_vline(x=score, line_width=3, line_dash="dash", line_color="#111827")
    fig.update_layout(
        barmode="stack",
        height=180,
        xaxis_title="Score",
        yaxis_title="",
        showlegend=True,
        margin=dict(l=10, r=10, t=20, b=10),
    )
    return fig



def plot_batch_score_histogram(df: pd.DataFrame):
    if df.empty:
        return go.Figure()
    return px.histogram(df, x="score_300_900", nbins=20, title="Score Distribution")



def plot_action_distribution(df: pd.DataFrame):
    if df.empty:
        return go.Figure()
    plot_df = (
        df.assign(action_label=df["policy_action"].map(humanize_token))
        .groupby("action_label", as_index=False)
        .size()
        .rename(columns={"size": "count"})
        .sort_values("count", ascending=False)
    )
    return px.bar(plot_df, x="action_label", y="count", title="Action Distribution")



def plot_stage_distribution(df: pd.DataFrame):
    if df.empty:
        return go.Figure()
    plot_df = df.groupby("stage", as_index=False).size().rename(columns={"size": "count"})
    return px.pie(plot_df, names="stage", values="count", title="Stage Distribution", hole=0.45)



def plot_reason_frequency(df: pd.DataFrame):
    plot_df = reason_frequency_table(df)
    if plot_df.empty:
        return go.Figure()
    top_df = plot_df.head(10).sort_values("count", ascending=True)
    return px.bar(top_df, x="count", y="reason_text", orientation="h", title="Top Driver Frequency")



def plot_data_quality_summary(scored_df: pd.DataFrame, invalid_df: pd.DataFrame):
    plot_df = pd.DataFrame(
        {
            "category": ["Scored", "Rejected", "Has Missing Fields"],
            "count": [
                len(scored_df),
                len(invalid_df),
                int((scored_df.get("completeness_ratio", pd.Series(dtype=float)) < 1).sum()) if not scored_df.empty else 0,
            ],
        }
    )
    return px.bar(plot_df, x="category", y="count", title="Data Quality Summary")



def plot_policy_threshold_map(policy_thresholds: pd.DataFrame):
    if policy_thresholds.empty:
        return go.Figure()
    fig = px.timeline(
        policy_thresholds.assign(
            start=pd.to_datetime(policy_thresholds["min_score"], unit="D", origin="1970-01-01"),
            end=pd.to_datetime(policy_thresholds["max_score"], unit="D", origin="1970-01-01"),
        ),
        x_start="start",
        x_end="end",
        y="stage",
        color="decision",
        title="Policy Threshold Map",
    )
    fig.update_xaxes(title="Relative score band")
    return fig
