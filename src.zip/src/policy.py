from __future__ import annotations

from typing import Any

import pandas as pd

from .utils import humanize_token


def apply_policy_to_score(stage: str, score: float, policy_rules: dict[str, Any]) -> dict[str, Any]:
    stage_rules = policy_rules.get("stages", {}).get(stage, {})
    bands = stage_rules.get("bands", [])
    for band in bands:
        lower = float(band.get("min_score", 0))
        upper = float(band.get("max_score", 901))
        if lower <= score < upper:
            return {
                "stage": stage,
                "decision": band.get("decision"),
                "decision_label": humanize_token(band.get("decision")),
                "zone": band.get("zone"),
                "zone_label": humanize_token(band.get("zone")),
                "band_min": lower,
                "band_max": upper,
            }
    return {
        "stage": stage,
        "decision": "manual_review",
        "decision_label": humanize_token("manual_review"),
        "zone": "manual_review",
        "zone_label": humanize_token("manual_review"),
        "band_min": None,
        "band_max": None,
    }


def apply_policy_to_dataframe(df: pd.DataFrame, artifacts: Any) -> pd.DataFrame:
    out = df.copy()
    policy_rules = getattr(artifacts, "policy_rules", {})
    rows = []
    for _, row in out.iterrows():
        p = apply_policy_to_score(str(row.get("stage", "")), float(row.get("score_300_900", 0) or 0), policy_rules)
        rows.append(p)
    pol = pd.DataFrame(rows)
    out["decision_zone"] = pol["zone"]
    out["policy_action"] = pol["decision"]
    out["policy_action_label"] = pol["decision_label"]
    out["decision_zone_label"] = pol["zone_label"]
    out["band_min"] = pol["band_min"]
    out["band_max"] = pol["band_max"]
    return out


def build_policy_threshold_table(policy_rules: dict[str, Any]) -> pd.DataFrame:
    rows = []
    for stage, info in policy_rules.get("stages", {}).items():
        for band in info.get("bands", []):
            rows.append({
                "stage": stage,
                "stage_label": info.get("label", stage),
                "min_score": band.get("min_score"),
                "max_score": band.get("max_score"),
                "decision": humanize_token(band.get("decision")),
                "zone": humanize_token(band.get("zone")),
                "score_range": f"{band.get('min_score')} - {band.get('max_score')}",
            })
    return pd.DataFrame(rows)
